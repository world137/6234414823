package lab8_2;

public class Question {
    private String text, answer;
    
    public Question(String question) {
        this.text = question;
    }
    public Question() {
        this.text = "";
    }
    
    public void setText(String question) {
        text = question;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    public String getAnswer() {
        return answer;
    }
    public boolean checkAnswer(String response){
        return (response.equals(answer));  
    }
    public void display(){
        System.out.println(text);
    }
}