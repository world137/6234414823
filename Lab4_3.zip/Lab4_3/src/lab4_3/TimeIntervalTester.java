
package lab4_3;

import java.util.Scanner;

public class TimeIntervalTester {

    public static void main(String[] args) {
         Scanner input = new Scanner(System.in);

        System.out.print("Enter start time: ");
        String start = input.nextLine();
        System.out.print("Enter end time: ");
        String end = input.nextLine();

        TimeInterval time = new TimeInterval(start,end);

        System.out.println(time.getHours() + time.getMinutes());


    }

}
