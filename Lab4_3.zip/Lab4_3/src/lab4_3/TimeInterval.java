package lab4_3;

public class TimeInterval {

    private String s_time;
    private String e_time;

    public TimeInterval(String s,String e){

        this.s_time=s;
        this.e_time=e;
    }

    public int getHours(){

        String h1 = this.s_time.substring(0,2);
        String m1 = this.s_time.substring(2,s_time.length());

        String h2 = this.e_time.substring(0,2);
        String m2 = this.e_time.substring(2,e_time.length());

        int H1 = Integer.parseInt(h1)*60+Integer.parseInt(m1);
        int H2 = Integer.parseInt(h2)*60+Integer.parseInt(m2);

        return Math.abs((H1-H2)/60);
          }

    public int getMinutes(){

        String h1 = this.s_time.substring(0,2);
        String m1 = this.s_time.substring(2,s_time.length());

        String h2 = this.e_time.substring(0,2);
        String m2 = this.e_time.substring(2,e_time.length());

        int time1 = Integer.parseInt(h1)*60+Integer.parseInt(m1);
        int time2 = Integer.parseInt(h2)*60+Integer.parseInt(m2);

        return Math.abs( (time1-time2)%60 );
    }

}