package lab3_1;
public class InsectPopulationTester {
    public static void main(String[] args){
        InsectPopulation numInsect = new InsectPopulation(10);

        numInsect.breed();
        numInsect.spray();        
        System.out.println("Number of insects : " + numInsect.getNumInsect());
        numInsect.breed();
        numInsect.spray();
        System.out.println("Number of insects : " + numInsect.getNumInsect());
        numInsect.breed();
        numInsect.spray();
        System.out.printf("Number of insects : " + "%.2f\n" , numInsect.getNumInsect());
    }
}