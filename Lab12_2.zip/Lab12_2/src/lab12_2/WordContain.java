package lab12_2;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;
public class WordContain {

    public static void main(String[] args) {
        ArrayList<String> notin = new ArrayList<>();
        ArrayList<String> list_word = new ArrayList<>();
        String str_word;
        
        Scanner text = new Scanner(System.in);
        System.out.print("Enter a sentence: ");
        String data = text.nextLine();
        String[] data1 = data.split(" ");
        
        try{
            File file = new File ("wordlist.txt");
            Scanner word = new Scanner (file);
            str_word = word.nextLine();
            while (word.hasNext()){
                list_word.add(str_word);
                str_word = word.nextLine();
            }
            for(int i = 0; i<data1.length ;i++){
                if(!list_word.contains(data1[i])){
                    notin.add(data1[i]);
                    }
                }
            System.out.println("Words not cintained: ");
            if (notin.size()>0){
                for (int k = 0;k<notin.size();k++){
                    System.out.println(notin.get(k));
                }
            }
        
            else{
                System.out.println("N/A");
            }   
        }
        catch(FileNotFoundException e){
            System.out.println(e);
        }
        catch(IOException e){
            System.out.println(e);
        }
        catch(Exception e){
            System.out.println(e);
        }
        System.out.println(data1);
    }
}
