
package lab6_1;

public class CannnonBallTester {

    public static void main(String[] args) {
        CannnonBall ball = new CannnonBall(100);
        ball.simulatedFlight();
        System.out.println(ball.calculusFlight(ball.getSimulatedTime()));
    }
    
}
