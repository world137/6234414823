
package lab6_1;

public class CannnonBall {
    private double initV;
    private double simS;
    private double simT ;
    public static final double g = 9.81;
    public CannnonBall(double v){
       initV = v;
    }
    public void simulatedFlight(){
        double delS;
        double delT;
        double v = initV;
        for (int i = 1 ;v >= 0;i++){     
            simT = i/100;
            delT = 0.01;
            delS = v * delT;
            simS += delS;
            v -= g*delT;
            if(i % 100 == 0){
                System.out.printf("Distance on "+simT+" sec: %.3f",simS);
                System.out.println();
            }   
            
        }
        System.out.printf("Final distance: %.3f",simS);
        System.out.printf(" Total time: %.2f",simT);
        System.out.println();
        System.out.printf("Distance from calculus equation: ");
    }
    public double calculusFlight(double t){
        simS = -0.5*g*t*t+initV*t;
        simS = Math.round(simS*1000.00)/1000.00;
        return simS;
    }
    public double getSimulatedTime(){
        return simT;
    }
    public double getSimulatedDistance(){
        return simS;
    }
}
