
package lab9_1;

public class PizzaSpecial extends Pizza{
    private String special;
    public PizzaSpecial (String menu, double price, String toppings){
        super(menu, price);
        this.special = toppings;
    }
    
    public String getToppings(){
        return special;
    }
    
    @Override
    public String toString(){
        return super.toString()+" : "+special;
    }
}

