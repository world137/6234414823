package lab2_2;

public class HollePrintor {

    public static void main(String[] args) {
    String str1 = "Hello, World";
    String str2 = str1.replace("o", "a").replace("e", "o").replace("a","e");
    System.out.println(str2);   
    }
    
}
