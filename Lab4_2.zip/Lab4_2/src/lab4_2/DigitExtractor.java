
package lab4_2;


public class DigitExtractor {
    private int number;

    public DigitExtractor(int anInteger){

        this.number = anInteger;

    }

    public int nextDigit(){

        int newNum = this.number%10;
        this.number = this.number/10;
        return newNum;

    }

}

