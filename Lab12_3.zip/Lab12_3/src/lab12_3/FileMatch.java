
package lab12_3;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.Scanner;
public class FileMatch {

    
    public static void main(String[] args) {
         ArrayList<AccountRecord> accountRecordArrayList = new ArrayList<>();
        ArrayList<TransactionRecord> transactionRecordArrayList = new ArrayList<>();

        File master = new File("master.txt");
        try (Scanner masterScanner = new Scanner(master)) {
            while (masterScanner.hasNextLine()) {
                String line = masterScanner.nextLine();
                String[] masterSplit = line.split(" ");
                int accNo = Integer.parseInt(masterSplit[0]);
                String name = masterSplit[1] + " " + masterSplit[2];
                double balance = Double.parseDouble(masterSplit[3]);
                AccountRecord accRec = new AccountRecord(accNo, name, balance);
                accountRecordArrayList.add(accRec);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        File trans = new File("trans.txt");
        try (Scanner transScanner = new Scanner(trans)) {
            while (transScanner.hasNextLine()) {
                String line = transScanner.nextLine();
                String[] transSplit = line.split(" ");
                int accNo = Integer.parseInt(transSplit[0]);
                double balance = Double.parseDouble(transSplit[1]);
                if (transactionRecordArrayList.size() != 0) {
                    TransactionRecord lastTrans = transactionRecordArrayList.get((transactionRecordArrayList.size()-1));
                    if (lastTrans.getAcctNo() == accNo) {
                        lastTrans.setBalance(lastTrans.getBalance() + balance);
                        lastTrans.setTransCnt(lastTrans.getTransCnt()+1);
                    }
                    else {
                        TransactionRecord transRec = new TransactionRecord(accNo, balance);
                        transactionRecordArrayList.add(transRec);
                    }
                }
                else {
                    TransactionRecord transRec = new TransactionRecord(accNo, balance);
                    transactionRecordArrayList.add(transRec);
                }
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }

//        System.out.println(accountRecordArrayList);
//        System.out.println(transactionRecordArrayList);

        for (AccountRecord acc : accountRecordArrayList) {
            for (TransactionRecord transRec : transactionRecordArrayList) {
                if (acc.getAcctNo() == transRec.getAcctNo()) {
                    acc.combine(transRec);
                    break;
                }
            }
        }

//        System.out.println(accountRecordArrayList);

        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat", "rw")) {
            for (AccountRecord acc : accountRecordArrayList) {
                r.writeInt(acc.getAcctNo());
                r.writeChar('\n');
                String name = acc.getName();
                for (int i = name.length(); i < 30; i++) {
                    name += " ";
                }
                r.writeChars(name);
                r.writeChar('\n');
                r.writeDouble(acc.getBalance());
                r.writeChar('\n');
                r.writeInt(acc.getTransCnt());
                r.writeChar('\n');
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ArrayList<AccountRecord> accountRecordRead = new ArrayList<>();
        try (RandomAccessFile r = new RandomAccessFile("newMaster.dat", "r")) {
            while (r.getFilePointer() < r.length()) {
                int accNo = r.readInt();
//                System.out.println(r.readInt());
                r.seek(r.getFilePointer()+2);
                String name = r.readLine();
                Double balance = r.readDouble();
//                System.out.println(r.readLine());
//                System.out.println(r.readDouble());
                r.seek(r.getFilePointer()+2);
                int transCnt = r.readInt();
//                System.out.println(r.readInt());
                r.seek(r.getFilePointer()+2);
                AccountRecord acc = new AccountRecord(accNo, name, balance, transCnt);
                accountRecordRead.add(acc);
            }
        }
        catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        catch (IOException e) {
            e.printStackTrace();
        }
        double balance = 0.0;
        int noTrans = 0;
        for (AccountRecord acc : accountRecordRead) {
            balance += acc.getBalance();
            if (acc.getTransCnt() == 0) {
                noTrans++;
            }
        }
        System.out.print("Total Account Record : ");
        System.out.println(accountRecordRead.size());
        System.out.print("Total Balance : ");
        System.out.println(balance);
        System.out.print("No transaction : ");
        System.out.println(noTrans + " account.");
    }
    
}
