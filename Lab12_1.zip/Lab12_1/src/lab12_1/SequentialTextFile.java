package lab12_1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class SequentialTextFile {

    public static void main(String[] args) throws FileNotFoundException {

        String string = "";
        Scanner scanner = new Scanner(System.in);
        boolean firstLine = true;
        int lineCnt = 0;
        int wordCnt = 0;
        int charCnt = 0;

        System.out.println("*You may now start typing (type quit to exit)*");

        while (true) {
            String line = scanner.nextLine();
            if (line.equals("quit")) {
                break;
            }
            else {
                if (!firstLine) {
                    string += "\n";
                    string += line;
                }
                else {
                    string += line;
                    firstLine = false;
                }
            }
        }

//        System.out.println(string);

        File file = new File("output.txt");
        PrintWriter output = new PrintWriter(file);
        output.print(string);
        output.close();

        Scanner read = new Scanner(file);
        while (read.hasNextLine()) {
            String line = read.nextLine();
            lineCnt++;
            String[] words = line.split(" ");
            wordCnt += words.length;
            /*
            นับ characters โดยไม่นับ space
            for (String word : words) {
                charCnt += word.length();
            }
            */
            charCnt += line.length();
        }
        read.close();
        System.out.print("Total characters : ");
        System.out.println(charCnt);
        System.out.print("Total words : ");
        System.out.println(wordCnt);
        System.out.print("Total lines : ");
        System.out.println(lineCnt);

    }

}
