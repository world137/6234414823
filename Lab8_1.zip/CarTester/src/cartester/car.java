package cartester;

public class car{
    public double gas;
    public double efficiency;
    public car(int gas,int gasUse){
        this.gas = gas;
        this.efficiency = gasUse;
    }
    public void drive(double distance){
        if(gas<=(distance/efficiency)){
            System.out.println("You cannot drive too far, please add gas");
        }else{
            gas = gas-(distance/efficiency);
        }
    }
    public void addGas(double amount){
        gas += amount;
    }
    public void setGas(double amount){
        
    }
    public double getGas(){

        return gas;
    }
    public double getEfficiency(){
        return efficiency;
    }
}
