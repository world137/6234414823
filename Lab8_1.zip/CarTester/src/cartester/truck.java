package cartester;
public class truck extends car {
    public int M_weight;
    public int weight;
    public truck(int gas, int gasUse,int M_weight,int weight) {
        super(gas, gasUse);
        this.M_weight = M_weight;
        this.weight = weight;
        if(M_weight < weight){
            weight = M_weight;
        }
    }
    @Override
    public void drive(double distance){
        if(0 < weight && weight< 1 && gas>=(distance/efficiency)){
            gas = gas-(distance/efficiency);
        }else if(1<=weight && weight<=10 && gas>=(distance/efficiency)+((distance/efficiency)*0.1)){
            gas = gas-((distance/efficiency)+((distance/efficiency)*0.1));
        }else if(11<=weight && weight<=20 && gas>=(distance/efficiency)+((distance/efficiency)*0.2)){
            gas = gas-((distance/efficiency)+((distance/efficiency)*0.2));
        }else if(20<weight && gas>=(distance/efficiency)+((distance/efficiency)*0.3)){
            gas = gas-((distance/efficiency)+((distance/efficiency)*0.3));
        }else{
            System.out.println("You cannot drive too far, please add gas");
        }
        
    }
}
