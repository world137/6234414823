package lab11_1;

import java.util.ArrayList;

public class MusicBox implements SimpleQueue {

    private ArrayList<Object> queue;
    private int inQueue;

    public MusicBox() {
        this.queue = new ArrayList<>();
        this.inQueue = 0;
    }

    @Override
    public void enqueue(Object o) {
        queue.add(o);
        inQueue++;
        System.out.println(o.toString() + " is added in queue");
    }

    @Override
    public void dequeue() {
        if (inQueue == 0) return;
        System.out.println("Now playing " + queue.get(0).toString());
        queue.remove(0);
        inQueue--;
    }
}