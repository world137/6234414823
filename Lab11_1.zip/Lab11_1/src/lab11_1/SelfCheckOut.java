package lab11_1;

import java.util.ArrayList;

public class SelfCheckOut implements SimpleQueue{
    
private ArrayList<Product> queue;
    private int inQueue;
    private double amount;

    public SelfCheckOut() {
        this.queue = new ArrayList<>();
        this.inQueue = 0;
        this.amount = 0.0;
    }

    @Override
    public void enqueue(Object o) {
        if (!(o instanceof Product)) return;
        queue.add((Product) o);
        inQueue++;
        System.out.println(((Product) o).getName() + " is added in queue");
    }

    @Override
    public void dequeue() {
        if (inQueue == 0) return;
        amount += queue.get(0).getPrice();
        queue.remove(0);
        inQueue--;
    }

    public double getAmount() {
        return amount;
    }

}

