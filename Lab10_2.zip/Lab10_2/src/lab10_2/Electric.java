package lab10_2;
public interface Electric {

    double LOW_VOLTAGE = 480.0;
    double HIGH_VOLTAGE = 600.0;

    double getVoltage();

}