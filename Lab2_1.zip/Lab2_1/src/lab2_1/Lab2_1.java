package lab2_1;
import java.awt.Rectangle;
import java.util.Random;
public class Lab2_1 {

    public static void main(String[] args) {
       Random rdm = new Random();
       int x = rdm.nextInt()%49+1;
       int y = rdm.nextInt()%49+1;
       int w = rdm.nextInt()%49+1;
       int h = rdm.nextInt()%49+1;
       int x2 = rdm.nextInt()%49+1;
       int y2 = rdm.nextInt()%49+1;
       int w2 = rdm.nextInt()%49+1;
       int h2 = rdm.nextInt()%49+1;
       Rectangle r1 = new Rectangle(x,y,w,h); 
       Rectangle r2 = new Rectangle(x2,y2,w2,h2);
       System.out.println(r1);
       System.out.println(r2);
       Rectangle r3 = r1.intersection(r2);
       boolean TF = r3.isEmpty() ;
       System.out.println("Is the intersected rectangle empty?:"+TF);
    }
    
}
