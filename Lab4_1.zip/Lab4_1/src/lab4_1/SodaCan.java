
package lab4_1;

public class SodaCan {
    private double height;
    private double diameter;

    public SodaCan(double h,double d){

        this.height=h;
        this.diameter=d;

    }
    public String getVolume(){

        double vol = Math.PI*(this.height)*(this.diameter/2)*(this.diameter/2);
        return "Volume: "+Math.round(vol*100)/100.00;
    }
    public String getSurfaceArea(){

        double sa = 2*Math.PI*(this.height)*(this.diameter/2)+ (2*Math.PI*(this.diameter/2)*(this.diameter/2));
        return "Surface area: "+Math.round(sa*100)/100.00;

    }



}

