
package lab4_1;

import java.util.Scanner;

public class SodaTester {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter height: ");
        double Hi = input.nextDouble();

        System.out.print("Enter diameter: ");
        double Dia = input.nextDouble();

        SodaCan cc = new SodaCan(Hi,Dia);
        System.out.println(cc.getVolume());
        System.out.println(cc.getSurfaceArea());
        
    }

}

