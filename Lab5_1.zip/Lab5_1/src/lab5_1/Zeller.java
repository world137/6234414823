
package lab5_1;

public class Zeller {
    private static int day; 
    private static int month; 
    private static int year;
    
    Zeller(int day,int month,int year){
        this.day = day;
        this.month = month;
        this.year = year;
        
    }

    public enum Day {
        SUNDAY("Sunday"), MONDAY("Monday"), TUESDAY("Tuesday"), WEDNESDAY("Wesnesday"),THURSDAY("Thursday"), FRIDAY("Friday"), SATURDAY("Saturday");
        public final String days;
        Day(String days){
            this.days = days;
        }
    }
    public Day getDayOfWeek(){
        int number = (day+(year%100)+((year%100)/4)+(((month+1)*26)/10)+((year/100)/4)+(5*(year/100)))%7;
            switch (number) {
                case 2 : return Day.MONDAY;
                case 3 : return Day.TUESDAY;
                case 4 : return  Day.WEDNESDAY;
                case 5 : return  Day.THURSDAY;
                case 6 : return  Day.FRIDAY;
                case 0 : return  Day.SATURDAY;
                case 1 : return  Day.SUNDAY;
            }
            return null ;
    }
}


