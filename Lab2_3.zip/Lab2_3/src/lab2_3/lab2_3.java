package lab2_3;
import java.util.Calendar;
import java.util.GregorianCalendar;

public class lab2_3{
    public static void main(final String[] args) {
        GregorianCalendar cal = new GregorianCalendar(2019, Calendar.JANUARY,8);
        cal.add(Calendar.DAY_OF_MONTH,100);
        int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
        int month = cal.get(Calendar.MONTH)+1 ;
        int year = cal.get(Calendar.YEAR);
        int weekday = cal.get(Calendar.DAY_OF_WEEK);
        System.out.println(weekday+" "+dayOfMonth+" "+month+" "+year);
        GregorianCalendar BD = new GregorianCalendar(2000, Calendar.NOVEMBER,19);
        BD.add(Calendar.DAY_OF_MONTH,10000);
        int day = BD.get(Calendar.DAY_OF_MONTH);
        int BDmonth = BD.get(Calendar.MONTH)+1 ;
        int BDyear = BD.get(Calendar.YEAR);
        int BDweekday = BD.get(Calendar.DAY_OF_WEEK);
        System.out.println(BDweekday+" "+day+" "+BDmonth+" "+BDyear);
    }

}
