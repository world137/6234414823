package lab9_2;
public class sine extends Taylor {
    public sine(int k, double x) {
        super(k, x);
    }

    public double getApprox() {
        double aprox = 0.0;
        for (int n = 0; n <= this.getIter(); n++) {
            aprox += ((Math.pow(-1, n))*(Math.pow(this.getValue(), 2*n+1)))/(factorial(2*n+1));
        }
        return aprox;
    }

    public void printValue() {
        System.out.print("Value from Math.sin() is ");
        System.out.println(Math.sin(this.getValue())+".");
        System.out.print("Approximated value is ");
        System.out.println(this.getApprox()+".");
    }

}
