package lab9_2;
public class expo extends Taylor {

    public expo(int k, double x) {
        super(k, x);
    }

    public double getApprox() {
        double aprox = 0.0;
        for (int n = 0; n <= this.getIter(); n++) {
            aprox += (Math.pow(this.getValue(), n))/(factorial(n));
        }
        return aprox;
    }

    public void printValue() {
        System.out.print("Value from Math.exp() is ");
        System.out.println(Math.exp(this.getValue())+".");
        System.out.print("Approximated value is ");
        System.out.println(this.getApprox()+".");
    }

}
