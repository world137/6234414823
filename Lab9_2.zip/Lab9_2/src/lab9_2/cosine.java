package lab9_2;
public class cosine extends Taylor {

    public cosine(int k, double x) {
        super(k, x);
    }

    public double getApprox() {
        double aprox = 0.0;
        for (int n = 0; n <= this.getIter(); n++) {
            aprox += ((Math.pow(-1, n))*(Math.pow(this.getValue(), 2*n)))/(factorial(2*n));
        }
        return aprox;
    }

    public void printValue() {
        System.out.print("Value from Math.cos() is ");
        System.out.println(Math.cos(this.getValue())+".");
        System.out.print("Approximated value is ");
        System.out.println(this.getApprox()+".");
    }

}