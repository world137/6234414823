package lab3_2;
public class LetterPrinter {
    public static void main(String[] args) {
      Letter mail = new Letter();
        mail.FormTo("Jade", "Clarissa");
        mail.addLine("We must find Simon quickly.");
        mail.addLine("He might be in danger.");
        System.out.println(mail.getText());
    } 
}