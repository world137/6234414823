package lab3_2;
public class Letter {
    private String nameForm,nameTo,line,text,str;
    public void FormTo(String from, String to){
         this.nameForm = from;
         this.nameTo = to;
     }
    {
        str = "";
    }
    public void addLine(String line){
        this.line = line;
        str = str + line + "\n";
     }
    public String getText(){
        text = "deer " + nameForm + " :" + "\n\n" 
                +str+ "\n\n" + "Sincerely," + "\n\n" + nameTo;
        
        return text ;
        
    }
}