package lab3_3;
public class CashRegesterTester {
    public static void main(String[] args) {
        CashRegister change = new CashRegister();
        change.recordPurchase(50, 10);
        change.recordTaxablePurchase(20);
        change.enterPayment(100);
        System.out.printf("Your change is " + "%.1f\n",change.givechange());
    }
}