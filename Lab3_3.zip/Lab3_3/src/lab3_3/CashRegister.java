package lab3_3;
public class CashRegister {
    private double total,payment;
public CashRegister(){
    total = 0;
    payment = 0;
}
public void recordTaxablePurchase(double TaxGoods){
    total = (TaxGoods+((TaxGoods*7)/100)) + total;
}
public void recordPurchase(double price1,double price2){
    total = total + price1 + price2;
}
public void enterPayment(double pay){
    payment = payment + pay;
}
public double givechange(){
    double change = payment - total;
    return change;
}
}